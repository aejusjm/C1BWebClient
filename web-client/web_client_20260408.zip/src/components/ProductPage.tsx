// 상품관리 페이지 컴포넌트 - 상품 목록 및 관리 기능
import { useState, useEffect } from 'react'
import { useUser } from '../contexts/UserContext'
import { useAlert } from '../contexts/AlertContext'
import './ProductPage.css'

const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:3001'
const API_URL = `${API_BASE}/api/products`

interface Product {
  seq: number
  user_id: string
  good_name_ss: string
  seller_cd: string
  display_id_ss: string | null
  display_id_cp: string | null
  t_url: string | null
  t_img_url: string | null
  mp_delv_Price: number | null
  store_id: string | null
  biz_idx: string | null
  get_date: string | null
}

function ProductPage() {
  const { userInfo } = useUser()
  const { showAlert } = useAlert()
  
  // 검색 필터 상태
  const [productCode, setProductCode] = useState('')
  const [productName, setProductName] = useState('')
  // 이미지 확대 상태
  const [enlargedImage, setEnlargedImage] = useState<string | null>(null)
  // 상품 목록
  const [products, setProducts] = useState<Product[]>([])
  // 로딩 상태
  const [loading, setLoading] = useState(false)
  // 페이징 상태
  const [currentPage, setCurrentPage] = useState(1)
  const [pageSize, setPageSize] = useState(20)
  const [totalCount, setTotalCount] = useState(0)
  const [totalPages, setTotalPages] = useState(0)
  // 삭제요청 모달 상태
  const [showDeleteModal, setShowDeleteModal] = useState(false)
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [deleteType, setDeleteType] = useState('즉시삭제')
  const [deleteReason, setDeleteReason] = useState('브랜드 상품')
  const [customReason, setCustomReason] = useState('')
  // 이미지 로드 오류 상태
  const [imageErrors, setImageErrors] = useState<Set<number>>(new Set())

  // 컴포넌트 마운트 시 상품 목록 로드
  useEffect(() => {
    loadProducts()
  }, [currentPage, pageSize])

  // 상품 목록 로드
  const loadProducts = async () => {
    try {
      setLoading(true)
      let url = `${API_URL}/products/${userInfo.userId}?page=${currentPage}&limit=${pageSize}`
      
      if (productCode) {
        url += `&productCode=${encodeURIComponent(productCode)}`
      }
      
      if (productName) {
        url += `&productName=${encodeURIComponent(productName)}`
      }
      
      const response = await fetch(url)
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }
      
      const result = await response.json()
      
      console.log('상품 목록 응답:', result)
      
      if (result.success) {
        console.log('첫 번째 상품:', result.data[0])
        setProducts(result.data)
        setTotalCount(result.pagination.totalCount)
        setTotalPages(result.pagination.totalPages)
      } else {
        await showAlert(result.message || '상품 목록을 불러오는데 실패했습니다.')
      }
    } catch (error) {
      console.error('상품 목록 로드 오류:', error)
      await showAlert('상품 목록을 불러오는 중 오류가 발생했습니다.')
    } finally {
      setLoading(false)
    }
  }

  // 검색 기능
  const handleSearch = () => {
    setCurrentPage(1) // 검색 시 첫 페이지로
    loadProducts()
  }

  // 상품코드 엔터키 검색
  const handleProductCodeKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      setCurrentPage(1)
      loadProducts()
    }
  }

  // 상품명 엔터키 검색
  const handleProductNameKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      setCurrentPage(1)
      loadProducts()
    }
  }

  // 페이지 변경
  const handlePageChange = (page: number) => {
    setCurrentPage(page)
  }

  // 페이지 크기 변경
  const handlePageSizeChange = (size: number) => {
    setPageSize(size)
    setCurrentPage(1)
  }

  // 페이지 번호 생성
  const getPageNumbers = () => {
    const pages = []
    const maxVisible = 5
    let startPage = Math.max(1, currentPage - Math.floor(maxVisible / 2))
    let endPage = Math.min(totalPages, startPage + maxVisible - 1)
    
    if (endPage - startPage < maxVisible - 1) {
      startPage = Math.max(1, endPage - maxVisible + 1)
    }
    
    for (let i = startPage; i <= endPage; i++) {
      pages.push(i)
    }
    
    return pages
  }

  // 마켓 링크 열기 (팝업)
  const openMarketLink = async (url: string | null, marketName: string) => {
    if (!url) {
      await showAlert(`${marketName} 링크가 없습니다.`)
      return
    }
    
    // 팝업 창 열기 (가로 1000px, 세로 800px)
    window.open(
      url,
      `${marketName}_popup`,
      'width=1000,height=800,scrollbars=yes,resizable=yes'
    )
  }

  // 스마트스토어 링크 생성
  const getSmartStoreUrl = (storeId: string | null, displayId: string | null) => {
    if (!storeId || !displayId) return null
    return `https://smartstore.naver.com/${storeId}/products/${displayId}`
  }

  // 쿠팡 링크 생성
  const getCoupangUrl = (displayId: string | null) => {
    if (!displayId) return null
    return `http://www.coupang.com/vp/products/${displayId}`
  }

  // 삭제요청 모달 열기
  const openDeleteModal = (product: Product) => {
    setSelectedProduct(product)
    setDeleteType('즉시삭제')
    setDeleteReason('브랜드 상품')
    setCustomReason('')
    setShowDeleteModal(true)
  }

  // 삭제요청 모달 닫기
  const closeDeleteModal = () => {
    setShowDeleteModal(false)
    setSelectedProduct(null)
    setDeleteType('즉시삭제')
    setDeleteReason('브랜드 상품')
    setCustomReason('')
  }

  // 삭제요청 제출
  const handleDeleteRequest = async () => {
    if (!selectedProduct) return

    // 기타 선택 시 직접 입력 확인
    if (deleteReason === '기타' && !customReason.trim()) {
      await showAlert('삭제사유를 입력해주세요.')
      return
    }

    try {
      const finalReason = deleteReason === '기타' ? customReason.trim() : deleteReason

      const response = await fetch(`${API_URL}/delete-request`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          user_id: userInfo.userId,
          gu_seq: selectedProduct.seq,
          biz_idx: selectedProduct.biz_idx,
          del_reason: finalReason,
          del_type: deleteType
        })
      })

      const result = await response.json()

      if (result.success) {
        await showAlert('삭제요청이 완료되었습니다.')
        closeDeleteModal()
        loadProducts()
      } else {
        await showAlert(result.message || '삭제요청 중 오류가 발생했습니다.')
      }
    } catch (error) {
      console.error('삭제요청 오류:', error)
      await showAlert('삭제요청 중 오류가 발생했습니다.')
    }
  }

  // 이미지 로드 오류 처리
  const handleImageError = (productSeq: number) => {
    setImageErrors(prev => new Set(prev).add(productSeq))
  }

  // 이미지 URL을 프록시를 통해 안전하게 처리
  const getSafeImageUrl = (url: string | null): string | null => {
    if (!url) return null
    // 백엔드 프록시를 통해 이미지 로드 (CORS 및 SSL 문제 해결)
    return `${API_BASE}/api/image/proxy?url=${encodeURIComponent(url)}`
  }

  if (loading) {
    return (
      <div className="product-page">
        <div className="product-page-header">
          <h1 className="page-title">📦 상품관리</h1>
        </div>
        <div style={{ textAlign: 'center', padding: '40px' }}>
          데이터를 불러오는 중입니다...
        </div>
      </div>
    )
  }

  return (
    <div className="product-page">
      {/* 페이지 헤더 */}
      <div className="product-page-header">
        <h1 className="page-title">📦 상품관리</h1>
      </div>

      {/* 검색 필터 */}
      <div className="search-filter">
        <div className="filter-row">
          <div className="filter-group">
            <label className="filter-label">상품코드:</label>
            <input 
              type="text"
              className="filter-input"
              value={productCode}
              onChange={(e) => setProductCode(e.target.value)}
              onKeyPress={handleProductCodeKeyPress}
              placeholder="상품코드 입력 (접두사 자동 제거)"
            />
          </div>
          <div className="filter-group">
            <label className="filter-label">상품명:</label>
            <input 
              type="text"
              className="filter-input"
              value={productName}
              onChange={(e) => setProductName(e.target.value)}
              onKeyPress={handleProductNameKeyPress}
              placeholder="상품명 입력"
            />
          </div>
          <button className="search-btn" onClick={handleSearch}>
            상품검색
          </button>
        </div>
      </div>

      {/* 상품 개수 및 페이지 크기 선택 */}
      <div className="product-header">
        <div className="product-count">
          전체 <strong>{totalCount}</strong>개 상품
        </div>
        <div className="page-size-selector">
          <label>페이지당 표시:</label>
          <select value={pageSize} onChange={(e) => handlePageSizeChange(Number(e.target.value))}>
            <option value={20}>20개</option>
            <option value={30}>30개</option>
            <option value={50}>50개</option>
          </select>
        </div>
      </div>

      {/* 상품 목록 */}
      {products.length === 0 ? (
        <div className="no-products-message">
          등록된 상품이 없습니다.
        </div>
      ) : (
        <div className="product-list">
          {products.map((product) => (
            <div key={product.seq} className="product-card">
              {/* 상품 이미지 */}
              <div 
                className="product-image"
                onClick={() => product.t_img_url && setEnlargedImage(getSafeImageUrl(product.t_img_url))}
              >
                {product.t_img_url && !imageErrors.has(product.seq) ? (
                  <img 
                    src={getSafeImageUrl(product.t_img_url) || ''} 
                    alt={product.good_name_ss}
                    onError={() => handleImageError(product.seq)}
                  />
                ) : (
                  <div className="image-placeholder">
                    {imageErrors.has(product.seq) ? '🚫' : '📦'}
                  </div>
                )}
                {product.t_img_url && !imageErrors.has(product.seq) && (
                  <div className="image-overlay">🔍</div>
                )}
              </div>

              {/* 상품 정보 및 마켓 버튼 */}
              <div className="product-info">
                <div className="product-details">
                  <div className="product-name">{product.good_name_ss || '상품명 없음'}</div>
                  <div className="product-meta-row">
                    <div className="product-code">
                      <span className="meta-label">C1B 코드:</span>
                      <span className="meta-value">{product.seller_cd || '-'}</span>
                    </div>
                    <div className="product-price">
                      <span className="meta-label">배송비:</span>
                      <span className="meta-value">{product.mp_delv_Price ? product.mp_delv_Price.toLocaleString() : '0'}원</span>
                    </div>
                    <div className="product-date">
                      <span className="meta-label">등록일자:</span>
                      <span className="meta-value">{product.get_date ? product.get_date.substring(0, 16) : '-'}</span>
                    </div>
                  </div>
                </div>
                
                {/* 마켓 버튼 */}
                <div className="market-buttons">
                  <button 
                    className="action-btn smartstore"
                    onClick={() => openMarketLink(
                      getSmartStoreUrl(product.store_id, product.display_id_ss),
                      '스마트스토어'
                    )}
                    disabled={!product.display_id_ss || !product.store_id}
                  >
                    스마트스토어
                  </button>
                  <button 
                    className="action-btn coupang"
                    onClick={() => openMarketLink(
                      getCoupangUrl(product.display_id_cp),
                      '쿠팡'
                    )}
                    disabled={!product.display_id_cp}
                  >
                    쿠 팡
                  </button>
                </div>
              </div>

              {/* 액션 버튼 */}
              <div className="product-actions">
                <button 
                  className="action-btn delete"
                  onClick={() => openDeleteModal(product)}
                >
                  삭제요청
                </button>
                <button 
                  className="action-btn taobao"
                  onClick={() => openMarketLink(product.t_url, '타오바오')}
                  disabled={!product.t_url}
                >
                  타오바오
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* 페이징 */}
      {totalPages > 1 && (
        <div className="pagination">
          <button 
            className="page-btn"
            onClick={() => handlePageChange(1)}
            disabled={currentPage === 1}
          >
            처음
          </button>
          <button 
            className="page-btn"
            onClick={() => handlePageChange(currentPage - 1)}
            disabled={currentPage === 1}
          >
            이전
          </button>
          
          {getPageNumbers().map(page => (
            <button
              key={page}
              className={`page-btn ${currentPage === page ? 'active' : ''}`}
              onClick={() => handlePageChange(page)}
            >
              {page}
            </button>
          ))}
          
          <button 
            className="page-btn"
            onClick={() => handlePageChange(currentPage + 1)}
            disabled={currentPage === totalPages}
          >
            다음
          </button>
          <button 
            className="page-btn"
            onClick={() => handlePageChange(totalPages)}
            disabled={currentPage === totalPages}
          >
            마지막
          </button>
        </div>
      )}

      {/* 이미지 확대 모달 */}
      {enlargedImage && (
        <div className="image-modal-overlay">
          <div className="image-modal-content">
            <button 
              className="image-modal-close"
              onClick={() => setEnlargedImage(null)}
            >
              ✕
            </button>
            <div className="enlarged-image">
              <img src={enlargedImage} alt="확대 이미지" />
            </div>
            <p className="image-modal-hint">클릭하여 닫기</p>
          </div>
        </div>
      )}

      {/* 삭제요청 모달 */}
      {showDeleteModal && selectedProduct && (
        <div className="delete-modal-overlay">
          <div className="delete-modal-content">
            <div className="delete-modal-header">
              <h2>삭제요청</h2>
              <button className="delete-modal-close" onClick={closeDeleteModal}>✕</button>
            </div>

            <div className="delete-modal-body">
              {/* 상품 정보 표시 */}
              <div className="delete-product-info">
                <p><strong>상품명:</strong> {selectedProduct.good_name_ss}</p>
                <p><strong>C1B 코드:</strong> {selectedProduct.seller_cd}</p>
              </div>

              {/* 삭제구분 */}
              <div className="delete-form-group">
                <label className="delete-form-label">삭제구분</label>
                <div className="delete-radio-group">
                  <label className="delete-radio-label">
                    <input
                      type="radio"
                      value="즉시삭제"
                      checked={deleteType === '즉시삭제'}
                      onChange={(e) => setDeleteType(e.target.value)}
                    />
                    <span>즉시삭제</span>
                  </label>
                  <label className="delete-radio-label">
                    <input
                      type="radio"
                      value="검토요청"
                      checked={deleteType === '검토요청'}
                      onChange={(e) => setDeleteType(e.target.value)}
                    />
                    <span>검토요청</span>
                  </label>
                </div>
              </div>

              {/* 삭제사유 */}
              <div className="delete-form-group">
                <label className="delete-form-label">삭제사유</label>
                <select
                  className="delete-select"
                  value={deleteReason}
                  onChange={(e) => {
                    setDeleteReason(e.target.value)
                    if (e.target.value !== '기타') {
                      setCustomReason('')
                    }
                  }}
                >
                  <option value="브랜드 상품">브랜드 상품</option>
                  <option value="판매금지 상품">판매금지 상품</option>
                  <option value="상품명 수정">상품명 수정</option>
                  <option value="기타">기타</option>
                </select>
              </div>

              {/* 기타 사유 직접 입력 */}
              {deleteReason === '기타' && (
                <div className="delete-form-group">
                  <label className="delete-form-label">사유 입력</label>
                  <textarea
                    className="delete-textarea"
                    placeholder="삭제 사유를 입력해주세요"
                    value={customReason}
                    onChange={(e) => setCustomReason(e.target.value)}
                    rows={3}
                  />
                </div>
              )}
            </div>

            <div className="delete-modal-footer">
              <button className="delete-modal-btn cancel" onClick={closeDeleteModal}>
                취소
              </button>
              <button className="delete-modal-btn submit" onClick={handleDeleteRequest}>
                요청
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default ProductPage
