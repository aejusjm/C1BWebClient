// 사용자관리 페이지 컴포넌트 - 사용자 조회 및 수정
import { useState, useEffect } from 'react'
import { useUser } from '../contexts/UserContext'
import { useAlert } from '../contexts/AlertContext'
import './UserManagementPage.css'

const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:3001'
const API_URL = `${API_BASE}/api/users`
const MARKET_API_URL = `${API_BASE}/api/market`

interface StoreInfo {
  biz_idx: number
  storeName: string
  id: string
  storeId: string
  appId: string
  appSecret: string
  useYn: string
  isNew?: boolean
}

interface CoupangInfo {
  biz_idx: number
  storeName: string
  accountId: string
  vendorCode: string
  accessKey: string
  secretKey: string
  useYn: string
  isNew?: boolean
}

interface ServerInfo {
  server_id: string
  server_name: string
}

interface User {
  user_id: string
  user_pwd: string
  user_name: string
  start_date: string | null
  end_date: string | null
  user_type: string
  margin_rate: number
  user_phone: string
  user_email: string
  input_date: string
  server_id: string
  last_proc_date: string | null
  proc_ord: number
  batch_date: string | null
  last_delete_date: string | null
  use_yn: string
  reupload_target_yn: string
  get_cnt: number
  del_cnt: number
  del_days: number
  sale_keep_days: number
  cs_phone: string
  cs_phone_apply: string
  biz_hours: string
}

interface UserManagementPageProps {
  onNavigate?: (menu: string) => void
}

function UserManagementPage({ onNavigate }: UserManagementPageProps) {
  const { setUserInfo } = useUser()
  const { showAlert, showConfirm } = useAlert()
  const [users, setUsers] = useState<User[]>([])
  const [loading, setLoading] = useState(false)
  const [searchParams, setSearchParams] = useState({
    userName: '',
    userPhone: ''
  })
  
  // 페이징 상태
  const [currentPage, setCurrentPage] = useState(1)
  const [itemsPerPage, setItemsPerPage] = useState(20) // 페이지당 항목 수
  
  // 수정/추가 모달 상태
  const [showEditModal, setShowEditModal] = useState(false)
  const [isNewUser, setIsNewUser] = useState(false)
  const [selectedUser, setSelectedUser] = useState<User | null>(null)
  const [editData, setEditData] = useState<Partial<User>>({})
  
  // 마켓연동 모달 상태
  const [showMarketModal, setShowMarketModal] = useState(false)
  const [marketUserId, setMarketUserId] = useState('')
  const [activeTab, setActiveTab] = useState<'smartstore' | 'coupang'>('smartstore')
  const [smartStores, setSmartStores] = useState<StoreInfo[]>([
    { biz_idx: 1, storeName: '', id: '', storeId: '', appId: '', appSecret: '', useYn: 'Y' },
    { biz_idx: 2, storeName: '', id: '', storeId: '', appId: '', appSecret: '', useYn: 'Y' },
    { biz_idx: 3, storeName: '', id: '', storeId: '', appId: '', appSecret: '', useYn: 'Y' }
  ])
  const [coupangStores, setCoupangStores] = useState<CoupangInfo[]>([
    { biz_idx: 1, storeName: '', accountId: '', vendorCode: '', accessKey: '', secretKey: '', useYn: 'Y' },
    { biz_idx: 2, storeName: '', accountId: '', vendorCode: '', accessKey: '', secretKey: '', useYn: 'Y' },
    { biz_idx: 3, storeName: '', accountId: '', vendorCode: '', accessKey: '', secretKey: '', useYn: 'Y' }
  ])
  
  // 서버 목록 상태
  const [servers, setServers] = useState<ServerInfo[]>([])

  // 컴포넌트 마운트 시 전체 사용자 조회 및 서버 목록 조회
  useEffect(() => {
    loadUsers()
    loadServers()
  }, [])

  // 서버 목록 조회
  const loadServers = async () => {
    try {
      const response = await fetch(`${API_URL}/servers`)
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }
      
      const result = await response.json()
      
      if (result.success) {
        setServers(result.data)
      }
    } catch (error) {
      console.error('서버 목록 조회 오류:', error)
    }
  }

  // 사용자 목록 조회
  const loadUsers = async (params?: { userName?: string; userPhone?: string }) => {
    try {
      setLoading(true)
      const queryParams = new URLSearchParams()
      
      if (params?.userName) queryParams.append('userName', params.userName)
      if (params?.userPhone) queryParams.append('userPhone', params.userPhone)
      
      const url = queryParams.toString() ? `${API_URL}?${queryParams}` : API_URL
      console.log('API 요청:', url)
      
      const response = await fetch(url)
      console.log('응답 상태:', response.status, response.statusText)
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }
      
      const result = await response.json()
      console.log('응답 데이터:', result)
      
      if (result.success) {
        setUsers(result.data)
      } else {
        await showAlert(result.message || '사용자 목록 조회에 실패했습니다.')
      }
    } catch (error) {
      console.error('사용자 목록 조회 오류:', error)
      
      if (error instanceof TypeError && error.message.includes('fetch')) {
        await showAlert('백엔드 서버에 연결할 수 없습니다.\n\n백엔드 서버가 실행 중인지 확인해주세요.\n(http://localhost:3001)')
      } else {
        await showAlert(`사용자 목록을 불러오는 중 오류가 발생했습니다.\n\n오류: ${error instanceof Error ? error.message : String(error)}`)
      }
    } finally {
      setLoading(false)
    }
  }

  // 검색 버튼 클릭
  const handleSearch = () => {
    setCurrentPage(1) // 검색 시 첫 페이지로 이동
    loadUsers(searchParams)
  }

  // 페이징 계산
  const indexOfLastItem = currentPage * itemsPerPage
  const indexOfFirstItem = indexOfLastItem - itemsPerPage
  const currentUsers = users.slice(indexOfFirstItem, indexOfLastItem)
  const totalPages = Math.ceil(users.length / itemsPerPage)

  // 페이지 변경
  const handlePageChange = (pageNumber: number) => {
    setCurrentPage(pageNumber)
  }

  // 페이지당 항목 수 변경
  const handleItemsPerPageChange = (newItemsPerPage: number) => {
    setItemsPerPage(newItemsPerPage)
    setCurrentPage(1) // 첫 페이지로 이동
  }

  // 마켓연동 버튼 클릭
  const handleMarketConnection = async (userId: string) => {
    setMarketUserId(userId)
    setActiveTab('smartstore')
    await loadMarketData(userId)
    setShowMarketModal(true)
  }

  // 마켓 데이터 로드
  const loadMarketData = async (userId: string) => {
    await Promise.all([
      loadSmartStores(userId),
      loadCoupangStores(userId)
    ])
  }

  // 스마트스토어 목록 조회
  const loadSmartStores = async (userId: string) => {
    try {
      const response = await fetch(`${MARKET_API_URL}/smartstore/${userId}`)
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`)
      
      const result = await response.json()
      
      if (result.success && result.data.length > 0) {
        const loadedStores = [1, 2, 3].map(idx => {
          const found = result.data.find((s: any) => s.biz_idx === idx)
          return found ? {
            biz_idx: found.biz_idx,
            storeName: found.store_name || '',
            id: found.account_id || '',
            storeId: found.store_id || '',
            appId: found.client_id || '',
            appSecret: found.client_secret_sign || '',
            useYn: found.use_yn || 'Y',
            isNew: false
          } : {
            biz_idx: idx,
            storeName: '',
            id: '',
            storeId: '',
            appId: '',
            appSecret: '',
            useYn: 'Y',
            isNew: true
          }
        })
        setSmartStores(loadedStores)
      }
    } catch (error) {
      console.error('스마트스토어 조회 오류:', error)
    }
  }

  // 쿠팡 목록 조회
  const loadCoupangStores = async (userId: string) => {
    try {
      const response = await fetch(`${MARKET_API_URL}/coupang/${userId}`)
      if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`)
      
      const result = await response.json()
      
      if (result.success && result.data.length > 0) {
        const loadedStores = [1, 2, 3].map(idx => {
          const found = result.data.find((c: any) => c.biz_idx === idx)
          return found ? {
            biz_idx: found.biz_idx,
            storeName: found.store_name || '',
            accountId: found.accountId || '',
            vendorCode: found.vendorId || '',
            accessKey: found.accessKey || '',
            secretKey: found.secretKey || '',
            useYn: found.use_yn || 'Y',
            isNew: false
          } : {
            biz_idx: idx,
            storeName: '',
            accountId: '',
            vendorCode: '',
            accessKey: '',
            secretKey: '',
            useYn: 'Y',
            isNew: true
          }
        })
        setCoupangStores(loadedStores)
      }
    } catch (error) {
      console.error('쿠팡 조회 오류:', error)
    }
  }

  // 스마트스토어 개별 저장
  const handleSmartStoreSave = async (index: number) => {
    const store = smartStores[index]
    
    try {
      setLoading(true)
      const response = await fetch(`${MARKET_API_URL}/smartstore/${marketUserId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          biz_idx: store.biz_idx,
          store_name: store.storeName,
          account_id: store.id,
          store_id: store.storeId,
          client_id: store.appId,
          client_secret_sign: store.appSecret,
          use_yn: store.useYn
        })
      })

      const result = await response.json()
      if (result.success) {
        await showAlert('스마트스토어 정보가 저장되었습니다.')
        await loadSmartStores(marketUserId)
      } else {
        await showAlert(`저장 실패: ${result.message}`)
      }
    } catch (error) {
      console.error('스마트스토어 저장 오류:', error)
      await showAlert('저장 중 오류가 발생했습니다.')
    } finally {
      setLoading(false)
    }
  }

  // 쿠팡 개별 저장
  const handleCoupangSave = async (index: number) => {
    const store = coupangStores[index]
    
    try {
      setLoading(true)
      const response = await fetch(`${MARKET_API_URL}/coupang/${marketUserId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          biz_idx: store.biz_idx,
          store_name: store.storeName,
          accountId: store.accountId,
          vendorId: store.vendorCode,
          accessKey: store.accessKey,
          secretKey: store.secretKey,
          use_yn: store.useYn
        })
      })

      const result = await response.json()
      if (result.success) {
        await showAlert('쿠팡 정보가 저장되었습니다.')
        await loadCoupangStores(marketUserId)
      } else {
        await showAlert(`저장 실패: ${result.message}`)
      }
    } catch (error) {
      console.error('쿠팡 저장 오류:', error)
      await showAlert('저장 중 오류가 발생했습니다.')
    } finally {
      setLoading(false)
    }
  }

  // 스마트스토어 정보 변경
  const handleSmartStoreChange = (index: number, field: keyof StoreInfo, value: string) => {
    const updated = [...smartStores]
    updated[index] = { ...updated[index], [field]: value }
    setSmartStores(updated)
  }

  // 쿠팡 정보 변경
  const handleCoupangChange = (index: number, field: keyof CoupangInfo, value: string) => {
    const updated = [...coupangStores]
    updated[index] = { ...updated[index], [field]: value }
    setCoupangStores(updated)
  }

  // 페이지 번호 생성
  const getPageNumbers = () => {
    const pages = []
    const maxPagesToShow = 5
    
    let startPage = Math.max(1, currentPage - Math.floor(maxPagesToShow / 2))
    let endPage = Math.min(totalPages, startPage + maxPagesToShow - 1)
    
    if (endPage - startPage + 1 < maxPagesToShow) {
      startPage = Math.max(1, endPage - maxPagesToShow + 1)
    }
    
    for (let i = startPage; i <= endPage; i++) {
      pages.push(i)
    }
    
    return pages
  }

  // Enter 키 검색
  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSearch()
    }
  }

  // 신규 등록 버튼 클릭
  const handleAddClick = () => {
    setIsNewUser(true)
    setSelectedUser(null)
    setEditData({
      user_id: '',
      user_pwd: '',
      user_name: '',
      start_date: null,
      end_date: null,
      user_type: '',
      margin_rate: 0,
      user_phone: '',
      user_email: '',
      server_id: '',
      use_yn: 'Y',
      get_cnt: 0,
      del_cnt: 0,
      del_days: 0,
      sale_keep_days: 0,
      proc_ord: 0
    })
    setShowEditModal(true)
  }

  // 수정 버튼 클릭
  const handleEditClick = (user: User) => {
    setIsNewUser(false)
    setSelectedUser(user)
    setEditData(user)
    setShowEditModal(true)
  }

  // 해당 사용자로 로그인
  const handleLoginAs = async (user: User) => {
    const confirmed = await showConfirm(`${user.user_name}(${user.user_id}) 계정으로 로그인하시겠습니까?`)
    if (!confirmed) {
      return
    }

    // 종료일 체크
    if (user.end_date) {
      const endDate = new Date(user.end_date)
      const today = new Date()
      if (endDate < today) {
        await showAlert('사용기한이 지난 계정입니다.')
        return
      }
    }

    // 로컬스토리지에 사용자 정보 저장
    const newUserInfo = {
      userId: user.user_id,
      userName: user.user_name,
      userType: user.user_type,
      endDate: user.end_date || null
    }
    localStorage.setItem('userInfo', JSON.stringify(newUserInfo))
    
    // 로그인 성공 메시지 표시
    await showAlert(`${user.user_name} 계정으로 로그인되었습니다.`)
    
    // UserContext 업데이트 (메시지 확인 후)
    console.log('setUserInfo 호출:', newUserInfo)
    setUserInfo(newUserInfo)
    
    // 대시보드로 확실히 이동
    console.log('대시보드로 이동 시작, onNavigate:', onNavigate)
    
    if (onNavigate) {
      console.log('onNavigate 함수 호출')
      onNavigate('dashboard')
    } else {
      console.log('페이지 새로고침')
      window.location.reload()
    }
  }

  // 모달 닫기
  const closeEditModal = () => {
    setShowEditModal(false)
    setIsNewUser(false)
    setSelectedUser(null)
    setEditData({})
  }

  // 수정 데이터 변경
  const handleEditChange = (field: keyof User, value: any) => {
    setEditData({
      ...editData,
      [field]: value
    })
  }

  // 저장 (추가 또는 수정)
  const handleSave = async () => {
    // 필수 필드 검증
    if (!editData.user_id || !editData.user_pwd || !editData.user_name) {
      await showAlert('사용자ID, 비밀번호, 사용자명은 필수 입력 항목입니다.')
      return
    }
    
    try {
      setLoading(true)
      
      if (isNewUser) {
        // 신규 등록
        const response = await fetch(API_URL, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(editData)
        })
        
        const result = await response.json()
        
        if (result.success) {
          await showAlert('사용자가 등록되었습니다.')
          closeEditModal()
          loadUsers(searchParams)
        } else {
          await showAlert(result.message || '등록 중 오류가 발생했습니다.')
        }
      } else {
        // 수정
        if (!selectedUser) return
        
        console.log('사용자 수정 요청 데이터:', editData)
        
        const response = await fetch(`${API_URL}/${selectedUser.user_id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(editData)
        })
        
        console.log('사용자 수정 응답 상태:', response.status)
        
        const result = await response.json()
        
        console.log('사용자 수정 응답 결과:', result)
        
        if (result.success) {
          await showAlert('사용자 정보가 수정되었습니다.')
          closeEditModal()
          loadUsers(searchParams)
        } else {
          await showAlert(result.message || '수정 중 오류가 발생했습니다.')
        }
      }
    } catch (error) {
      console.error('사용자 저장 오류:', error)
      await showAlert('저장 중 오류가 발생했습니다.')
    } finally {
      setLoading(false)
    }
  }

  // 날짜 포맷팅
  const formatDate = (dateString: string | null) => {
    if (!dateString) return '-'
    return new Date(dateString).toLocaleDateString('ko-KR')
  }

  // 날짜시간 포맷팅
  const formatDateTime = (dateString: string | null) => {
    if (!dateString) return '-'
    return new Date(dateString).toLocaleString('ko-KR')
  }

  return (
    <div className="user-management-page">
      {/* 페이지 헤더 */}
      <div className="user-management-page-header">
        <h1 className="page-title">👥 사용자관리</h1>
        <button className="add-user-btn" onClick={handleAddClick}>
          + 신규 사용자 등록
        </button>
      </div>

      {/* 검색 영역 */}
      <div className="search-area">
        <div className="search-row">
          <div className="search-group">
            <label className="search-label">사용자명:</label>
            <input
              type="text"
              className="search-input"
              value={searchParams.userName}
              onChange={(e) => setSearchParams({...searchParams, userName: e.target.value})}
              onKeyPress={handleKeyPress}
              placeholder="사용자명 입력"
            />
          </div>
          <div className="search-group">
            <label className="search-label">전화번호:</label>
            <input
              type="text"
              className="search-input"
              value={searchParams.userPhone}
              onChange={(e) => setSearchParams({...searchParams, userPhone: e.target.value})}
              onKeyPress={handleKeyPress}
              placeholder="전화번호 입력"
            />
          </div>
          <button 
            className="search-btn" 
            onClick={handleSearch}
            disabled={loading}
          >
            {loading ? '검색 중...' : '검색'}
          </button>
        </div>
      </div>

      {/* 사용자 목록 테이블 */}
      <div className="user-table-container">
        <div className="table-header">
          <h3>사용자 목록 ({users.length}명)</h3>
          <div className="items-per-page">
            <label>페이지당 항목:</label>
            <select 
              value={itemsPerPage}
              onChange={(e) => handleItemsPerPageChange(parseInt(e.target.value))}
            >
              <option value={20}>20개</option>
              <option value={30}>30개</option>
              <option value={50}>50개</option>
              <option value={100}>100개</option>
            </select>
          </div>
        </div>
        <div className="table-wrapper">
          <table className="user-table">
            <thead>
              <tr>
                <th>순번</th>
                <th>사용자ID</th>
                <th>사용자명</th>
                <th>사용자종류</th>
                <th>연락처</th>
                <th>이메일</th>
                <th>시작일자</th>
                <th>종료일자</th>
                <th>마진율(%)</th>
                <th>서버ID</th>
                <th>처리순번</th>
                <th>사용여부</th>
                <th>재업로드여부</th>
                <th>등록일자</th>
                <th>마켓연동</th>
                <th>수정</th>
              </tr>
            </thead>
            <tbody>
              {users.length === 0 ? (
                <tr>
                  <td colSpan={15} className="no-data">
                    {loading ? '로딩 중...' : '조회된 사용자가 없습니다.'}
                  </td>
                </tr>
              ) : (
                currentUsers.map((user, index) => (
                  <tr key={user.user_id}>
                    <td>{indexOfFirstItem + index + 1}</td>
                    <td>{user.user_id}</td>
                    <td 
                      className="clickable-username"
                      onClick={() => handleLoginAs(user)}
                    >
                      {user.user_name}
                    </td>
                    <td>{user.user_type}</td>
                    <td>{user.user_phone}</td>
                    <td>{user.user_email}</td>
                    <td>{formatDate(user.start_date)}</td>
                    <td>{formatDate(user.end_date)}</td>
                    <td>{user.margin_rate}%</td>
                    <td>{user.server_id}</td>
                    <td>{user.proc_ord}</td>
                    <td>
                      <span className={`status-badge ${user.use_yn === 'Y' ? 'active' : 'inactive'}`}>
                        {user.use_yn === 'Y' ? '사용' : '미사용'}
                      </span>
                    </td>
                    <td>
                      <span className={`status-badge ${user.reupload_target_yn === 'Y' ? 'active' : 'inactive'}`}>
                        {user.reupload_target_yn === 'Y' ? '예' : '아니오'}
                      </span>
                    </td>
                    <td>{formatDateTime(user.input_date)}</td>
                    <td>
                      <button 
                        className="market-btn"
                        onClick={() => handleMarketConnection(user.user_id)}
                      >
                        마켓연동
                      </button>
                    </td>
                    <td>
                      <button 
                        className="edit-btn"
                        onClick={() => handleEditClick(user)}
                      >
                        수정
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* 페이징 */}
        {users.length > 0 && (
          <div className="pagination">
            <button
              className="page-btn"
              onClick={() => handlePageChange(1)}
              disabled={currentPage === 1}
            >
              ≪
            </button>
            <button
              className="page-btn"
              onClick={() => handlePageChange(currentPage - 1)}
              disabled={currentPage === 1}
            >
              ‹
            </button>
            
            {getPageNumbers().map((pageNum) => (
              <button
                key={pageNum}
                className={`page-btn ${currentPage === pageNum ? 'active' : ''}`}
                onClick={() => handlePageChange(pageNum)}
              >
                {pageNum}
              </button>
            ))}
            
            <button
              className="page-btn"
              onClick={() => handlePageChange(currentPage + 1)}
              disabled={currentPage === totalPages}
            >
              ›
            </button>
            <button
              className="page-btn"
              onClick={() => handlePageChange(totalPages)}
              disabled={currentPage === totalPages}
            >
              ≫
            </button>
            
            <span className="page-info">
              {currentPage} / {totalPages} 페이지 (총 {users.length}명)
            </span>
          </div>
        )}
      </div>

      {/* 수정/추가 모달 */}
      {showEditModal && (
        <div className="modal-overlay">
          <div className="modal-content">
            <div className="modal-header">
              <h3 className="modal-title">{isNewUser ? '신규 사용자 등록' : '사용자 정보 수정'}</h3>
              <button className="modal-close" onClick={closeEditModal}>✕</button>
            </div>

            <div className="modal-body">
              <div className="modal-grid">
                {/* 사용자ID */}
                <div className="modal-field">
                  <label>사용자ID *</label>
                  <input 
                    type="text" 
                    value={editData.user_id || ''} 
                    onChange={(e) => handleEditChange('user_id', e.target.value)}
                    disabled={!isNewUser}
                    placeholder={isNewUser ? '사용자ID 입력' : ''}
                  />
                </div>

                {/* 비밀번호 */}
                <div className="modal-field">
                  <label>비밀번호 *</label>
                  <input
                    type="password"
                    value={editData.user_pwd || ''}
                    onChange={(e) => handleEditChange('user_pwd', e.target.value)}
                    placeholder={isNewUser ? '비밀번호 입력' : ''}
                  />
                </div>

                {/* 사용자명 */}
                <div className="modal-field">
                  <label>사용자명 *</label>
                  <input
                    type="text"
                    value={editData.user_name || ''}
                    onChange={(e) => handleEditChange('user_name', e.target.value)}
                    placeholder={isNewUser ? '사용자명 입력' : ''}
                  />
                </div>

                {/* 사용자종류 */}
                <div className="modal-field">
                  <label>사용자종류</label>
                  <select
                    value={editData.user_type || '일반'}
                    onChange={(e) => handleEditChange('user_type', e.target.value)}
                  >
                    <option value="일반">일반</option>
                    <option value="우대">우대</option>
                    <option value="관리자">관리자</option>
                  </select>
                </div>

                {/* 연락처 */}
                <div className="modal-field">
                  <label>연락처</label>
                  <input
                    type="text"
                    value={editData.user_phone || ''}
                    onChange={(e) => handleEditChange('user_phone', e.target.value)}
                  />
                </div>

                {/* 이메일 */}
                <div className="modal-field">
                  <label>이메일</label>
                  <input
                    type="email"
                    value={editData.user_email || ''}
                    onChange={(e) => handleEditChange('user_email', e.target.value)}
                  />
                </div>

                {/* 시작일자 */}
                <div className="modal-field">
                  <label>시작일자</label>
                  <input
                    type="date"
                    value={editData.start_date ? new Date(editData.start_date).toISOString().split('T')[0] : ''}
                    onChange={(e) => handleEditChange('start_date', e.target.value)}
                  />
                </div>

                {/* 종료일자 */}
                <div className="modal-field">
                  <label>종료일자</label>
                  <input
                    type="date"
                    value={editData.end_date ? new Date(editData.end_date).toISOString().split('T')[0] : ''}
                    onChange={(e) => handleEditChange('end_date', e.target.value)}
                  />
                </div>

                {/* 마진율 */}
                <div className="modal-field">
                  <label>마진율(%)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={editData.margin_rate || 0}
                    onChange={(e) => handleEditChange('margin_rate', parseFloat(e.target.value))}
                  />
                </div>

                {/* 서버ID */}
                <div className="modal-field">
                  <label>서버ID</label>
                  <select
                    value={editData.server_id || ''}
                    onChange={(e) => handleEditChange('server_id', e.target.value)}
                  >
                    <option value="">선택하세요</option>
                    {servers.map((server) => (
                      <option key={server.server_id} value={server.server_id}>
                        {server.server_name} ({server.server_id})
                      </option>
                    ))}
                  </select>
                </div>

                {/* 사용여부 */}
                <div className="modal-field">
                  <label>사용여부</label>
                  <select
                    value={editData.use_yn || 'Y'}
                    onChange={(e) => handleEditChange('use_yn', e.target.value)}
                  >
                    <option value="Y">사용</option>
                    <option value="N">미사용</option>
                  </select>
                </div>

                {/* 재업로드여부 */}
                <div className="modal-field">
                  <label>재업로드여부</label>
                  <select
                    value={editData.reupload_target_yn || 'N'}
                    onChange={(e) => handleEditChange('reupload_target_yn', e.target.value)}
                  >
                    <option value="Y">예</option>
                    <option value="N">아니오</option>
                  </select>
                </div>

                {/* 상품건수 */}
                <div className="modal-field">
                  <label>상품건수</label>
                  <input
                    type="number"
                    value={editData.get_cnt || 0}
                    onChange={(e) => handleEditChange('get_cnt', parseInt(e.target.value))}
                  />
                </div>

                {/* 삭제할상품수 */}
                <div className="modal-field">
                  <label>삭제할상품수</label>
                  <input
                    type="number"
                    value={editData.del_cnt || 0}
                    onChange={(e) => handleEditChange('del_cnt', parseInt(e.target.value))}
                  />
                </div>

                {/* 삭제기준일수 */}
                <div className="modal-field">
                  <label>삭제기준일수</label>
                  <input
                    type="number"
                    value={editData.del_days || 0}
                    onChange={(e) => handleEditChange('del_days', parseInt(e.target.value))}
                  />
                </div>

                {/* 판매상품유지기간 */}
                <div className="modal-field">
                  <label>판매상품유지기간</label>
                  <input
                    type="number"
                    value={editData.sale_keep_days || 0}
                    onChange={(e) => handleEditChange('sale_keep_days', parseInt(e.target.value))}
                  />
                </div>

                {/* 처리순번 */}
                <div className="modal-field">
                  <label>처리순번</label>
                  <input
                    type="number"
                    value={editData.proc_ord || 0}
                    onChange={(e) => handleEditChange('proc_ord', parseInt(e.target.value))}
                  />
                </div>

                {/* 마지막처리일시 (읽기전용) */}
                <div className="modal-field">
                  <label>마지막처리일시</label>
                  <input
                    type="text"
                    value={editData.last_proc_date ? formatDateTime(editData.last_proc_date) : '-'}
                    disabled
                  />
                </div>

                {/* 배치실행일시 (읽기전용) */}
                <div className="modal-field">
                  <label>배치실행일시</label>
                  <input
                    type="text"
                    value={editData.batch_date ? formatDateTime(editData.batch_date) : '-'}
                    disabled
                  />
                </div>

                {/* 삭제처리일자 (읽기전용) */}
                <div className="modal-field">
                  <label>삭제처리일자</label>
                  <input
                    type="text"
                    value={editData.last_delete_date ? formatDate(editData.last_delete_date) : '-'}
                    disabled
                  />
                </div>

                {/* 고객센터 */}
                <div className="modal-field">
                  <label>고객센터</label>
                  <input
                    type="text"
                    value={editData.cs_phone || ''}
                    onChange={(e) => handleEditChange('cs_phone', e.target.value)}
                    placeholder="010-1234-5678"
                  />
                </div>

                {/* 상세페이지 적용 여부 */}
                <div className="modal-field">
                  <label>상세페이지 적용 여부</label>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <input
                      type="checkbox"
                      checked={editData.cs_phone_apply === 'Y'}
                      onChange={(e) => handleEditChange('cs_phone_apply', e.target.checked ? 'Y' : 'N')}
                      style={{ width: 'auto', cursor: 'pointer' }}
                    />
                    <span>적용</span>
                  </div>
                </div>

                {/* 영업시간 */}
                <div className="modal-field">
                  <label>영업시간</label>
                  <input
                    type="text"
                    value={editData.biz_hours || ''}
                    onChange={(e) => handleEditChange('biz_hours', e.target.value)}
                    placeholder="오전 9시 ~ 오후 6시"
                  />
                </div>
              </div>
            </div>

            <div className="modal-footer">
              <button className="modal-btn cancel-btn" onClick={closeEditModal}>
                취소
              </button>
              <button 
                className="modal-btn save-btn" 
                onClick={handleSave}
                disabled={loading}
              >
                {loading ? '저장 중...' : '저장'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 마켓연동 모달 */}
      {showMarketModal && (
        <div className="modal-overlay">
          <div className="modal-content market-modal">
            <div className="modal-header">
              <h3 className="modal-title">🔗 마켓연동 관리 - {marketUserId}</h3>
              <button className="modal-close" onClick={() => setShowMarketModal(false)}>×</button>
            </div>

            {/* 탭 메뉴 (MarketPage 스타일) */}
            <div className="market-tabs">
              <button
                className={`tab-btn ${activeTab === 'smartstore' ? 'active' : ''}`}
                onClick={() => setActiveTab('smartstore')}
              >
                📱 스마트스토어
              </button>
              <button
                className={`tab-btn ${activeTab === 'coupang' ? 'active' : ''}`}
                onClick={() => setActiveTab('coupang')}
              >
                🛍️ 쿠팡
              </button>
            </div>

            <div className="modal-body market-modal-body">
              {/* 스마트스토어 탭 */}
              {activeTab === 'smartstore' && (
                <div className="market-section">
                  <h3 className="section-title">스마트스토어 연동 정보</h3>
                  <div className="store-grid">
                    {smartStores.map((store, index) => (
                      <div key={index} className="store-card">
                        <h4 className="store-card-title">
                          스마트스토어 {index + 1}
                          {store.isNew ? (
                            <span className="new-badge">없음</span>
                          ) : store.useYn === 'N' ? (
                            <span className="disabled-badge">미사용</span>
                          ) : (
                            <span className="active-badge">사용</span>
                          )}
                        </h4>
                        <div className="form-group">
                          <label className="field-label">스토어명</label>
                          <input
                            type="text"
                            className="field-input"
                            value={store.storeName}
                            onChange={(e) => handleSmartStoreChange(index, 'storeName', e.target.value)}
                            placeholder="스토어명 입력"
                          />
                        </div>
                        <div className="form-group">
                          <label className="field-label">아이디</label>
                          <input
                            type="text"
                            className="field-input"
                            value={store.id}
                            onChange={(e) => handleSmartStoreChange(index, 'id', e.target.value)}
                            placeholder="아이디 입력"
                          />
                        </div>
                        <div className="form-group">
                          <label className="field-label">스토어 ID</label>
                          <input
                            type="text"
                            className="field-input"
                            value={store.storeId}
                            onChange={(e) => handleSmartStoreChange(index, 'storeId', e.target.value)}
                            placeholder="스토어 ID 입력"
                          />
                        </div>
                        <div className="form-group">
                          <label className="field-label">APP ID</label>
                          <input
                            type="text"
                            className="field-input"
                            value={store.appId}
                            onChange={(e) => handleSmartStoreChange(index, 'appId', e.target.value)}
                            placeholder="APP ID 입력"
                          />
                        </div>
                        <div className="form-group">
                          <label className="field-label">APP 시크릿</label>
                          <input
                            type="text"
                            className="field-input"
                            value={store.appSecret}
                            onChange={(e) => handleSmartStoreChange(index, 'appSecret', e.target.value)}
                            placeholder="APP 시크릿 입력"
                          />
                        </div>
                        <div className="form-group">
                          <label className="field-label">사용여부</label>
                          <select
                            className="field-input"
                            value={store.useYn}
                            onChange={(e) => handleSmartStoreChange(index, 'useYn', e.target.value)}
                          >
                            <option value="Y">사용</option>
                            <option value="N">미사용</option>
                          </select>
                        </div>
                        <button 
                          className="store-save-btn"
                          onClick={() => handleSmartStoreSave(index)}
                        >
                          저장
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 쿠팡 탭 */}
              {activeTab === 'coupang' && (
                <div className="market-section">
                  <h3 className="section-title">쿠팡 연동 정보</h3>
                  <div className="store-grid">
                    {coupangStores.map((store, index) => (
                      <div key={index} className="store-card">
                        <h4 className="store-card-title">
                          쿠팡 {index + 1}
                          {store.isNew ? (
                            <span className="new-badge">없음</span>
                          ) : store.useYn === 'N' ? (
                            <span className="disabled-badge">미사용</span>
                          ) : (
                            <span className="active-badge">사용</span>
                          )}
                        </h4>
                        <div className="form-group">
                          <label className="field-label">스토어명</label>
                          <input
                            type="text"
                            className="field-input"
                            value={store.storeName}
                            onChange={(e) => handleCoupangChange(index, 'storeName', e.target.value)}
                            placeholder="스토어명 입력"
                          />
                        </div>
                        <div className="form-group">
                          <label className="field-label">Account ID</label>
                          <input
                            type="text"
                            className="field-input"
                            value={store.accountId}
                            onChange={(e) => handleCoupangChange(index, 'accountId', e.target.value)}
                            placeholder="Account ID 입력"
                          />
                        </div>
                        <div className="form-group">
                          <label className="field-label">Vendor Code</label>
                          <input
                            type="text"
                            className="field-input"
                            value={store.vendorCode}
                            onChange={(e) => handleCoupangChange(index, 'vendorCode', e.target.value)}
                            placeholder="Vendor Code 입력"
                          />
                        </div>
                        <div className="form-group">
                          <label className="field-label">Access Key</label>
                          <input
                            type="text"
                            className="field-input"
                            value={store.accessKey}
                            onChange={(e) => handleCoupangChange(index, 'accessKey', e.target.value)}
                            placeholder="Access Key 입력"
                          />
                        </div>
                        <div className="form-group">
                          <label className="field-label">Secret Key</label>
                          <input
                            type="text"
                            className="field-input"
                            value={store.secretKey}
                            onChange={(e) => handleCoupangChange(index, 'secretKey', e.target.value)}
                            placeholder="Secret Key 입력"
                          />
                        </div>
                        <div className="form-group">
                          <label className="field-label">사용여부</label>
                          <select
                            className="field-input"
                            value={store.useYn}
                            onChange={(e) => handleCoupangChange(index, 'useYn', e.target.value)}
                          >
                            <option value="Y">사용</option>
                            <option value="N">미사용</option>
                          </select>
                        </div>
                        <button 
                          className="store-save-btn"
                          onClick={() => handleCoupangSave(index)}
                        >
                          저장
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default UserManagementPage
