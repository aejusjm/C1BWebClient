// 모바일 전용 사용자별 매출 페이지
import { useState, useEffect } from 'react'
import DatePicker from 'react-datepicker'
import 'react-datepicker/dist/react-datepicker.css'
import './MobileSalesPage.css'

const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:3001'
const API_URL = `${API_BASE}/api/stats`

/** 테스트계정 제외 시 제외할 user_id */
const EXCLUDED_TEST_USER_IDS = new Set(['user1', 'user2', 'user3', 'ybin583', 'admin', 'payuser'])

interface UserSalesStats {
  user_id: string
  user_name: string
  ss_store_count: number
  ss_order_count: number
  ss_sales: number
  cp_store_count: number
  cp_order_count: number
  cp_sales: number
  total_order_count: number
  total_sales: number
  end_date?: string | null
  user_type?: string
}

type SortField = 'user_name' | 'total_order_count' | 'total_sales'
type SortOrder = 'asc' | 'desc'

interface MobileSalesPageProps {
  userInfo?: {
    userId: string
    userName: string
    userType: string
    endDate: string | null
  }
  onLogout?: () => void
}

function MobileSalesPage({ userInfo, onLogout }: MobileSalesPageProps) {
  // 필터 상태
  const [dateFilter, setDateFilter] = useState('today')
  const [userName, setUserName] = useState('')
  const [useCustomDate, setUseCustomDate] = useState(false)
  const [startDate, setStartDate] = useState('')
  const [endDate, setEndDate] = useState('')
  const [hasSales, setHasSales] = useState(false)
  const [excludeTestAccounts, setExcludeTestAccounts] = useState(true)
  
  // 날짜 선택 모달
  const [showDateModal, setShowDateModal] = useState(false)
  const [tempStartDate, setTempStartDate] = useState<Date | null>(null)
  const [tempEndDate, setTempEndDate] = useState<Date | null>(null)
  
  // 정렬 상태
  const [sortField, setSortField] = useState<SortField>('total_sales')
  const [sortOrder, setSortOrder] = useState<SortOrder>('desc')
  
  // 데이터 상태
  const [stats, setStats] = useState<UserSalesStats[]>([])
  const [loading, setLoading] = useState(false)
  
  // 필터 패널 표시 여부
  const [showFilters, setShowFilters] = useState(false)

  // 데이터 로드
  useEffect(() => {
    loadStats()
  }, [dateFilter, userName, useCustomDate, startDate, endDate, sortField, sortOrder, hasSales, excludeTestAccounts])

  // 날짜를 YYYY-MM-DD 형식으로 변환
  const formatDateToString = (date: Date): string => {
    const year = date.getFullYear()
    const month = String(date.getMonth() + 1).padStart(2, '0')
    const day = String(date.getDate()).padStart(2, '0')
    return `${year}-${month}-${day}`
  }

  // 날짜 선택 모달 열기
  const openDateModal = () => {
    const today = new Date()
    
    if (startDate && endDate) {
      setTempStartDate(new Date(startDate))
      setTempEndDate(new Date(endDate))
    } else {
      setTempStartDate(today)
      setTempEndDate(today)
    }
    setShowDateModal(true)
  }

  // 날짜 선택 모달 닫기
  const closeDateModal = () => {
    setShowDateModal(false)
    setTempStartDate(null)
    setTempEndDate(null)
  }

  // 사용자 정의 날짜 적용
  const handleCustomDateApply = () => {
    if (!tempStartDate || !tempEndDate) {
      alert('시작일과 종료일을 모두 선택해주세요.')
      return
    }
    if (tempStartDate > tempEndDate) {
      alert('시작일은 종료일보다 이전이어야 합니다.')
      return
    }
    setStartDate(formatDateToString(tempStartDate))
    setEndDate(formatDateToString(tempEndDate))
    setUseCustomDate(true)
    setShowDateModal(false)
  }

  // 날짜 필터 변경
  const handleDateFilterChange = (filter: string) => {
    setDateFilter(filter)
    setUseCustomDate(false)
  }

  // 통계 데이터 로드
  const loadStats = async () => {
    setLoading(true)
    try {
      let url = `${API_URL}/user-sales?dateFilter=${dateFilter}&sortField=${sortField}&sortOrder=${sortOrder}`
      
      if (userName.trim()) {
        url += `&userName=${encodeURIComponent(userName.trim())}`
      }
      
      if (useCustomDate && startDate && endDate) {
        url += `&startDate=${startDate}&endDate=${endDate}`
      }
      
      const response = await fetch(url)
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`)
      }
      
      const result = await response.json()
      
      if (result.success) {
        let filteredData = result.data || []
        
        // 매출유 필터 적용
        if (hasSales) {
          filteredData = filteredData.filter((stat: UserSalesStats) => stat.total_sales > 0)
        }

        if (excludeTestAccounts) {
          filteredData = filteredData.filter(
            (stat: UserSalesStats) => !EXCLUDED_TEST_USER_IDS.has(stat.user_id)
          )
        }

        setStats(filteredData)
      }
    } catch (error) {
      console.error('사용자별 매출 통계 로드 오류:', error)
      alert('데이터를 불러오는 중 오류가 발생했습니다.')
      setStats([])
    } finally {
      setLoading(false)
    }
  }

  // 검색 버튼 클릭
  const handleSearch = () => {
    loadStats()
  }

  // 정렬 변경
  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')
    } else {
      setSortField(field)
      setSortOrder('desc')
    }
  }

  // 금액 포맷 (만원 단위)
  const formatAmount = (amount: number) => {
    return Math.floor(amount / 10000).toLocaleString()
  }

  // 로그아웃 처리
  const handleLogout = () => {
    if (window.confirm('로그아웃 하시겠습니까?')) {
      localStorage.removeItem('userInfo')
      if (onLogout) {
        onLogout()
      } else {
        window.location.reload()
      }
    }
  }

  return (
    <div className="mobile-sales-page">
      {/* 헤더 */}
      <div className="mobile-header">
        <div className="header-content">
          <div className="header-title">
            <h1>💰 사용자별 매출</h1>
            {userInfo && (
              <div className="user-badge">
                {userInfo.userName}
              </div>
            )}
          </div>
          <button className="logout-btn" onClick={handleLogout}>
            로그아웃
          </button>
        </div>
      </div>

      {/* 필터 토글 버튼 */}
      <div className="filter-toggle-section">
        <button 
          className={`filter-toggle-btn ${showFilters ? 'active' : ''}`}
          onClick={() => setShowFilters(!showFilters)}
        >
          {showFilters ? '▲' : '▼'} 필터 및 검색
        </button>
      </div>

      {/* 검색 조건 */}
      {showFilters && (
        <div className="mobile-search-section">
          {/* 날짜 필터 */}
          <div className="mobile-filter-group">
            <label className="filter-group-label">기간 선택</label>
            <div className="date-filters">
              <button 
                className={dateFilter === 'today' && !useCustomDate ? 'active' : ''}
                onClick={() => handleDateFilterChange('today')}
              >
                오늘
              </button>
              <button 
                className={dateFilter === 'yesterday' && !useCustomDate ? 'active' : ''}
                onClick={() => handleDateFilterChange('yesterday')}
              >
                어제
              </button>
              <button 
                className={dateFilter === 'thisWeek' && !useCustomDate ? 'active' : ''}
                onClick={() => handleDateFilterChange('thisWeek')}
              >
                이번주
              </button>
              <button 
                className={dateFilter === 'lastWeek' && !useCustomDate ? 'active' : ''}
                onClick={() => handleDateFilterChange('lastWeek')}
              >
                지난주
              </button>
              <button 
                className={dateFilter === 'thisMonth' && !useCustomDate ? 'active' : ''}
                onClick={() => handleDateFilterChange('thisMonth')}
              >
                이번달
              </button>
              <button 
                className={dateFilter === 'lastMonth' && !useCustomDate ? 'active' : ''}
                onClick={() => handleDateFilterChange('lastMonth')}
              >
                지난달
              </button>
              <button 
                className={`date-picker-btn ${useCustomDate ? 'active' : ''}`}
                onClick={openDateModal}
              >
                📅 기간선택
              </button>
            </div>
            {useCustomDate && startDate && endDate && (
              <div className="selected-date-range">
                {startDate} ~ {endDate}
              </div>
            )}
          </div>

          {/* 매출 / 테스트계정 제외 */}
          <div className="mobile-filter-group">
            <label className="filter-group-label">옵션</label>
            <div className="checkbox-group">
              <label className="checkbox-label">
                <input
                  type="checkbox"
                  checked={hasSales}
                  onChange={(e) => setHasSales(e.target.checked)}
                />
                <span>매출 있음</span>
              </label>
              <label className="checkbox-label">
                <input
                  type="checkbox"
                  checked={excludeTestAccounts}
                  onChange={(e) => setExcludeTestAccounts(e.target.checked)}
                />
                <span>테스트계정 제외</span>
              </label>
            </div>
          </div>

          {/* 사용자 검색 */}
          <div className="mobile-filter-group">
            <label className="filter-group-label">사용자 검색</label>
            <div className="search-input-group">
              <input 
                type="text"
                className="search-input"
                placeholder="이름 입력"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              />
              <button className="search-btn" onClick={handleSearch}>
                🔍 검색
              </button>
            </div>
          </div>

          {/* 정렬 옵션 */}
          <div className="mobile-filter-group">
            <label className="filter-group-label">정렬</label>
            <div className="sort-buttons">
              <button
                className={sortField === 'user_name' ? 'active' : ''}
                onClick={() => handleSort('user_name')}
              >
                이름순 {sortField === 'user_name' && (sortOrder === 'asc' ? '↑' : '↓')}
              </button>
              <button
                className={sortField === 'total_order_count' ? 'active' : ''}
                onClick={() => handleSort('total_order_count')}
              >
                주문수 {sortField === 'total_order_count' && (sortOrder === 'asc' ? '↑' : '↓')}
              </button>
              <button
                className={sortField === 'total_sales' ? 'active' : ''}
                onClick={() => handleSort('total_sales')}
              >
                매출액 {sortField === 'total_sales' && (sortOrder === 'asc' ? '↑' : '↓')}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 통계 카드 리스트 */}
      <div className="mobile-stats-container">
        {loading ? (
          <div className="loading-message">데이터를 불러오는 중입니다...</div>
        ) : stats.length === 0 ? (
          <div className="no-data-message">조회된 데이터가 없습니다.</div>
        ) : (
          <div className="stats-card-list">
            {stats.map((stat, index) => (
              <div key={stat.user_id} className="stat-card">
                <div className="card-header">
                  <div className="card-rank">#{index + 1}</div>
                  <div className="card-user-info">
                    <div className="card-username">{stat.user_name}</div>
                    <div className="card-userid">{stat.user_id}</div>
                  </div>
                </div>
                
                <div className="card-totals">
                  <div className="card-total-item highlight">
                    <span className="card-total-label">총 매출</span>
                    <span className="card-total-value">{formatAmount(stat.total_sales)} 만원</span>
                  </div>
                  <div className="card-total-item">
                    <span className="card-total-label">총 주문수</span>
                    <span className="card-total-value">{stat.total_order_count.toLocaleString()}</span>
                  </div>
                </div>

                <div className="card-details">
                  <div className="detail-section smartstore">
                    <div className="detail-header">📦 스마트스토어</div>
                    <div className="detail-row">
                      <span className="detail-label">스토어수</span>
                      <span className="detail-value">{stat.ss_store_count}</span>
                    </div>
                    <div className="detail-row">
                      <span className="detail-label">주문수</span>
                      <span className="detail-value">{stat.ss_order_count.toLocaleString()}</span>
                    </div>
                    <div className="detail-row">
                      <span className="detail-label">매출</span>
                      <span className="detail-value">{formatAmount(stat.ss_sales)} 만원</span>
                    </div>
                  </div>

                  <div className="detail-section coupang">
                    <div className="detail-header">🛒 쿠팡</div>
                    <div className="detail-row">
                      <span className="detail-label">스토어수</span>
                      <span className="detail-value">{stat.cp_store_count}</span>
                    </div>
                    <div className="detail-row">
                      <span className="detail-label">주문수</span>
                      <span className="detail-value">{stat.cp_order_count.toLocaleString()}</span>
                    </div>
                    <div className="detail-row">
                      <span className="detail-label">매출</span>
                      <span className="detail-value">{formatAmount(stat.cp_sales)} 만원</span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* 날짜 선택 모달 */}
      {showDateModal && (
        <div className="date-modal-overlay" onClick={closeDateModal}>
          <div className="date-modal-content" onClick={(e) => e.stopPropagation()}>
            <div className="date-modal-header">
              <h3>기간 선택</h3>
              <button className="date-modal-close" onClick={closeDateModal}>
                ✕
              </button>
            </div>
            <div className="date-modal-body">
              <div className="date-input-group">
                <label className="date-label">시작일</label>
                <DatePicker
                  selected={tempStartDate}
                  onChange={(date: Date | null) => setTempStartDate(date)}
                  dateFormat="yyyy-MM-dd"
                  dateFormatCalendar="yyyy년 M월"
                  className="date-input-modal"
                  placeholderText="시작일을 선택하세요"
                  showMonthDropdown
                  showYearDropdown
                  dropdownMode="select"
                />
              </div>
              <div className="date-input-group">
                <label className="date-label">종료일</label>
                <DatePicker
                  selected={tempEndDate}
                  onChange={(date: Date | null) => setTempEndDate(date)}
                  dateFormat="yyyy-MM-dd"
                  dateFormatCalendar="yyyy년 M월"
                  className="date-input-modal"
                  placeholderText="종료일을 선택하세요"
                  showMonthDropdown
                  showYearDropdown
                  dropdownMode="select"
                  minDate={tempStartDate || undefined}
                />
              </div>
            </div>
            <div className="date-modal-footer">
              <button className="date-modal-cancel" onClick={closeDateModal}>
                취소
              </button>
              <button className="date-modal-apply" onClick={handleCustomDateApply}>
                적용
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default MobileSalesPage
